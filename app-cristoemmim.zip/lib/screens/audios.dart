import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class AudiosPage extends StatefulWidget {
  const AudiosPage({super.key});

  @override
  State<AudiosPage> createState() => _AudiosPageState();
}

class _AudiosPageState extends State<AudiosPage> {
  late List<_AudioItem> _audios;

  @override
  void initState() {
    super.initState();

    _audios = [
      _AudioItem(nome: 'Veja o inacreditável', url: 'assets/audios/audio1.mp3'),
      _AudioItem(nome: 'Identidade', url: 'assets/audios/audio2.mp3'),
    ];

    for (var audio in _audios) {
      audio.player = AudioPlayer();

      audio.player!.playerStateStream.listen((state) {
        final isPlaying = state.playing;
        final isCompleted = state.processingState == ProcessingState.completed;

        setState(() {
          if (isCompleted) {
            audio.isPlaying = false;
            audio.isPaused = false;
          } else {
            audio.isPlaying = isPlaying;
            audio.isPaused = !isPlaying &&
                state.processingState == ProcessingState.ready;
          }
        });
      });
    }
  }

  @override
  void dispose() {
    for (var audio in _audios) {
      audio.player?.dispose();
    }
    super.dispose();
  }

  Future<void> _playAudio(_AudioItem audio) async {
    for (var other in _audios) {
      if (other != audio) {
        await other.player?.stop();
        other.isPlaying = false;
        other.isPaused = false;
      }
    }

    if (audio.isPaused) {
      await audio.player?.play();
    } else {
      await audio.player?.setAsset(audio.url);
      await audio.player?.play();
    }

    setState(() {
      for (var a in _audios) {
        if (a != audio) {
          a.isPlaying = false;
          a.isPaused = false;
        }
      }
      audio.isPlaying = true;
      audio.isPaused = false;
    });
  }

  Future<void> _pauseAudio(_AudioItem audio) async {
    await audio.player?.pause();
    setState(() {
      audio.isPlaying = false;
      audio.isPaused = true;
    });
  }

  Future<void> _stopAudio(_AudioItem audio) async {
    await audio.player?.stop();
    setState(() {
      audio.isPlaying = false;
      audio.isPaused = false;
    });
  }

  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        shape: const CircleBorder(),
        padding: const EdgeInsets.all(20),
        backgroundColor: color,
      ),
      child: Icon(icon, color: Colors.white, size: 28),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001F3F),
      appBar: AppBar(
        title: const Text('Áudios', style: TextStyle(color: Colors.amber)),
        backgroundColor: const Color(0xFF001F3F),
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Mensagens',
              style: TextStyle(
                color: Colors.amber,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _audios.length,
              itemBuilder: (context, index) {
                final audio = _audios[index];
                return Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        audio.nome,
                        style: const TextStyle(
                          color: Colors.amber,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildControlButton(
                            icon: Icons.play_arrow,
                            onPressed: (!audio.isPlaying)
                                ? () => _playAudio(audio)
                                : null,
                            color: Colors.green,
                          ),
                          const SizedBox(width: 20),
                          _buildControlButton(
                            icon: Icons.pause,
                            onPressed: audio.isPlaying
                                ? () => _pauseAudio(audio)
                                : null,
                            color: Colors.orange,
                          ),
                          const SizedBox(width: 20),
                          _buildControlButton(
                            icon: Icons.stop,
                            onPressed: (audio.isPlaying || audio.isPaused)
                                ? () => _stopAudio(audio)
                                : null,
                            color: Colors.red,
                          ),
                        ],
                      ),
                      const Divider(color: Colors.amber, height: 32),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _AudioItem {
  final String nome;
  final String url;
  bool isPlaying = false;
  bool isPaused = false;
  AudioPlayer? player;

  _AudioItem({required this.nome, required this.url});
}
